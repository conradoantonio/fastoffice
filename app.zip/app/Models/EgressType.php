<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class EgressType extends Model
{
	public $timestamps = false;
}
